function dYdt = lorenz_system(t, Y)
    % Sistema de Lorenz clásico
    sigma = 10;
    beta  = 8/3;

    % Ejemplos de comportamiento:
    % rho = 24.74; % Bifurcación de Hopf
    rho = 28.0;  % Caos débil (atractor de Lorenz)
    % rho = 99.96; % Caos más desarrollado
    % rho = 166.07;% Comportamiento intermitente
    % rho = 350.0; % Órbitas periódicas (no caóticas)

    % Variables
    x = Y(1);
    y = Y(2);
    z = Y(3);

    % Ecuaciones del sistema
    dxdt = sigma * (y - x);
    dydt = x * (rho - z) - y;
    dzdt = x * y - beta * z;

    % Vector columna (¡importante!)
    dYdt = [dxdt; dydt; dzdt];
end
