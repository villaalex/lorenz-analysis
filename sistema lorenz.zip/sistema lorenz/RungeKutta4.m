function [T, Y] = RungeKutta4(f, a, b, N, y0)
    % Método de Runge-Kutta de 4º orden
    h = (b - a) / (N - 1);
    T = linspace(a, b, N)';
    Y = zeros(N, length(y0));
    Y(1, :) = y0;

    for i = 1:N-1
        T(i+1, :) = T(i) + h;

        k1 = f(T(i), Y(i, :)');
        k2 = f(T(i) + h/2, Y(i, :)' + (h/2) * k1);
        k3 = f(T(i) + h/2, Y(i, :)' + (h/2) * k2);
        k4 = f(T(i+1), Y(i, :)' + h * k3);

        
        Y(i+1, :) = Y(i, :) + (h/6) * (k1 + 2*k2 + 2*k3 + k4)';
    end
end
