function [T, Y] = EulerMejorado(f, a, b, N, y0)
    % Método de Euler mejorado (Runge-Kutta de 2º orden)
    h = (b - a) / (N - 1);
    T = linspace(a, b, N)';
    Y = zeros(N, length(y0));
    Y(1,:) = y0;

    for i = 1:N-1
        T(i+1,:) = T(i) + h;

        k1 = f(T(i), Y(i,:)');                        % Pendiente inicial
        k2 = f(T(i) + h/2, Y(i,:)' + (h/2)*k1);       % Pendiente en el punto medio

        Y(i+1,:) = Y(i,:) + h * k2';                  % Actualización
    end
end
