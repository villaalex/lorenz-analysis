clear; clc; close all;

% Parámetros del sistema
a = 0;          
b = 500;         
N = 10000;      
y0 = [8.4853, 8.4853, 27.0000];

% Resolver con Euler mejorado
[T, Y] = EulerMejorado(@lorenz_system, a, b, N, y0);

% Extraer variables
x = Y(:,1); 
y = Y(:,2); 
z = Y(:,3);

% Gráfica 3D del atractor de Lorenz
figure('Color','w');
plot3(x, y, z, 'b', 'LineWidth', 1.0);
grid on;
xlabel('x');
ylabel('y');
zlabel('z');
title('Atractor de Lorenz usando el Método de Euler Mejorado (RK2)');
legend('Euler mejorado','Location', 'northeast');

view(45,25);
