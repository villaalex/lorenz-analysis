clear; clc; close all;

% Parámetros del sistema
a = 0;          
b = 40;         
N = 10000;      
y0 = [1, 1, 1];

% Resolver con Euler mejorado y RK4
[T_em, Y_em] = EulerMejorado(@lorenz_system, a, b, N, y0);
[T_rk, Y_rk] = RungeKutta4(@lorenz_system, a, b, N, y0);

% Extraer variables
xEM = Y_em(:,1); yEM = Y_em(:,2); zEM = Y_em(:,3);
xRK = Y_rk(:,1); yRK = Y_rk(:,2); zRK = Y_rk(:,3);

% Gráfica 3D comparativa
figure('Color','w');
plot3(xRK, yRK, zRK, 'b', 'LineWidth', 1.2); hold on;
plot3(xEM, yEM, zEM, 'k--', 'LineWidth', 0.9);
grid on;
xlabel('x');
ylabel('y');
zlabel('z');
title(' Euler Mejorado vs Runge-Kutta 4');
legend('Runge-Kutta 4','Euler mejorado','Location', 'northeast');
view(45,25);

figure('Color','w');
plot(T_rk, xRK, 'b', 'LineWidth', 1.0); hold on;
plot(T_em, xEM, 'r--', 'LineWidth', 0.8);
ylabel('x(t)');
xlabel('Tiempo');
title('Euler Mejorado vs Runge-Kutta 4');
legend('RK4','Euler Mejorado','Location','best');
grid on;

figure('Color','w');
plot(T_rk, yRK, 'b', 'LineWidth', 1.0); hold on;
plot(T_em, yEM, 'r--', 'LineWidth', 0.8);
ylabel('y(t)');
xlabel('Tiempo');
title('Variable y(t)');
legend('RK4','Euler Mejorado','Location','best');
grid on;

figure('Color','w');
plot(T_rk, zRK, 'b', 'LineWidth', 1.0); hold on;
plot(T_em, zEM, 'r--', 'LineWidth', 0.8);
xlabel('Tiempo');
ylabel('z(t)');
title('Variable z(t)');
legend('RK4','Euler Mejorado','Location','best');
grid on;
