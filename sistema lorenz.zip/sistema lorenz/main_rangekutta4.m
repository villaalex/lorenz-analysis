clear; clc; close all;

% Parámetros del problema
a = 0;          
b = 40;         
N = 10000;      
y0 = [1, 1, 1];          % Condición inicial 1
y1 = [1, 1.001, 1];      % Condición inicial 2 (ligeramente diferente)

% Resolver con Runge-Kutta 4
[T,  Y]  = RungeKutta4(@lorenz_system, a, b, N, y0);
[T1, Y1] = RungeKutta4(@lorenz_system, a, b, N, y1);

% Extraer variables
x  = Y(:,1);  y  = Y(:,2);  z  = Y(:,3);
x1 = Y1(:,1); y2 = Y1(:,2); z3 = Y1(:,3);

% Graficar el atractor
figure('Color','w');
plot3(x, y, z, 'b--', 'LineWidth', 0.6);% hold on;
%plot3(x1, y2, z3, 'k', 'LineWidth', 1.0);
grid on;
xlabel('x');ylabel('y');zlabel('z');
title('Atractor de Lorenz usando Runge-Kutta 4');
view(45,25);
%legend('Trayectoria 1', 'Trayectoria 2','Location', 'northeast');

figure('Color','w');
plot(T, x, 'r', 'LineWidth', 0.8); hold on;
plot(T1, x1, 'b--', 'LineWidth', 1.0);
xlabel('Tiempo');
ylabel('x(t)');
title('Comparación de x(t) entre dos condiciones iniciales');
legend('x(t) con [1,1,1]', 'x(t) con [1,1.001,1]', 'Location','best');
grid on;


figure('Color','w');
plot(T, y, 'r', 'LineWidth', 0.8); hold on;
plot(T1, y2, 'b', 'LineWidth', 1.0);
xlabel('Tiempo');
ylabel('y(t)');
title('Comparación de y(t) entre dos condiciones iniciales');
legend('y(t) con [1,1,1]', 'y(t) con [1,1.001,1]', 'Location','best');
grid on;


figure('Color','w');
plot(T, z, 'g', 'LineWidth', 0.8); hold on;
plot(T1, z3, 'k', 'LineWidth', 1.0);
xlabel('Tiempo');
ylabel('z(t)');
title('Comparación de z(t) entre dos condiciones iniciales');
legend('z(t) con [1,1,1]', 'z(t) con [1,1.001,1]', 'Location','best');
grid on;

error_x = abs(x - x1);
error_y = abs(y - y2);
error_z = abs(z - z3);

figure('Color','w');
semilogy(T, error_x, 'r', 'LineWidth', 1.2); hold on;
semilogy(T, error_y, 'g', 'LineWidth', 1.2);
semilogy(T, error_z, 'b--', 'LineWidth', 1.2);
xlabel('Tiempo');
ylabel('Error |Δ| (escala logarítmica)');
title('Crecimiento del error entre trayectorias iniciales cercanas');
legend('|Δx|','|Δy|','|Δz|','Location','best');
grid on;