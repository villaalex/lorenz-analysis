clear; clc; close all;

% Parámetros
a = 0;          
b = 50;         
N = 10000;      
y0 = [1, 1, 1];
y1 = [1, 1.001, 1];

% Resolver con Euler
[T,  Y]  = Euler(@lorenz_system, a, b, N, y0);
[T1, Y1] = Euler(@lorenz_system, a, b, N, y1);

% Extraer variables
x  = Y(:,1);  y  = Y(:,2);  z  = Y(:,3);
x1 = Y1(:,1); y2 = Y1(:,2); z3 = Y1(:,3);

% Graficar el atractor con Euler
figure('Color','w');
plot3(x, y, z, 'r', 'LineWidth', 0.6); hold on;
plot3(x1, y2, z3, 'b', 'LineWidth', 1.0);
grid on;
xlabel('x');
ylabel('y');
zlabel('z');
title('Atractor de Lorenz usando el Método de Euler');
legend('Trayectoria 1', 'Trayectoria 2','Location', 'northeast');
view(45,25);
