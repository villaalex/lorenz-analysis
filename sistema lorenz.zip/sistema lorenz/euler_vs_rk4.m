clear; clc; close all;

% Parámetros del problema
a = 0;          
b = 40;         
N = 10000;      
y0 = [1, 1, 1];

% Resolver con los dos métodos
[T_e, Y_e]  = Euler(@lorenz_system, a, b, N, y0);
[T_rk, Y_rk] = RungeKutta4(@lorenz_system, a, b, N, y0);

% Extraer variables
xE = Y_e(:,1); yE = Y_e(:,2); zE = Y_e(:,3);
xR = Y_rk(:,1); yR = Y_rk(:,2); zR = Y_rk(:,3);


figure('Color','w');
plot3(xR, yR, zR, 'b', 'LineWidth', 1.0); hold on;
plot3(xE, yE, zE, 'r--', 'LineWidth', 0.8);
grid on;
xlabel('x');
ylabel('y');
zlabel('z');
title('Comparación: Método de Euler vs Runge-Kutta 4 (RK4)');
legend('Runge-Kutta 4', 'Euler','Location', 'northeast');

view(45,25);


figure('Color','w');
plot(T_rk, xR, 'b', 'LineWidth', 1.0); hold on;
plot(T_e, xE, 'r--', 'LineWidth', 0.8);
ylabel('x(t)');
legend('RK4','Euler','Location','best');
title('Comparación temporal entre Euler y RK4');

figure('Color','w');
plot(T_rk, yR, 'b', 'LineWidth', 1.0); hold on;
plot(T_e, yE, 'r--', 'LineWidth', 0.8);
ylabel('y(t)');

figure('Color','w');
plot(T_rk, zR, 'b', 'LineWidth', 1.0); hold on;
plot(T_e, zE, 'r--', 'LineWidth', 0.8);
xlabel('Tiempo');
ylabel('z(t)');
