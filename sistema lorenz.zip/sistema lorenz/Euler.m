function [T, Y] = Euler(f, a, b, N, y0)
    % Método de Euler explícito
    h = (b - a) / (N - 1);
    T = linspace(a, b, N)';
    Y = zeros(N, length(y0));
    Y(1, :) = y0;

    for i = 1:N-1
        T(i+1, :) = T(i) + h;
        k1 = f(T(i), Y(i, :)');      
        Y(i+1, :) = Y(i, :) + (h * k1)';
    end
end
