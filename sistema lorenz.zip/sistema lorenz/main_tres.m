clc; clear; close all;



% Parámetros del sistema
sigma = 10;
rho   = 28;
beta  = 8/3;

% Intervalo de integración
a = 0;        % tiempo inicial
b = 40;       % tiempo final
N = 8000;     % número de pasos

% Condiciones iniciales (original y perturbada)
y0  = [1; 1; 1];          % trayectoria 1
y0b = [1; 1.001; 1];      % trayectoria 2 (ligeramente distinta)

% Definimos el sistema de Lorenz (f = dy/dt)
f = @(t, y) [ sigma*(y(2) - y(1));
              y(1)*(rho - y(3)) - y(2);
              y(1)*y(2) - beta*y(3) ];


h = (b - a) / (N - 1);       
T = linspace(a, b, N)';      


Y = zeros(N, length(y0));
Y(1,:) = y0';
for i = 1:N-1
    k1 = f(T(i), Y(i,:)');
    k2 = f(T(i) + h/2, Y(i,:)' + (h/2)*k1);
    k3 = f(T(i) + h/2, Y(i,:)' + (h/2)*k2);
    k4 = f(T(i+1), Y(i,:)' + h*k3);
    Y(i+1,:) = Y(i,:) + (h/6)*(k1 + 2*k2 + 2*k3 + k4)';
end

Yb = zeros(N, length(y0b));
Yb(1,:) = y0b';
for i = 1:N-1
    k1 = f(T(i), Yb(i,:)');
    k2 = f(T(i) + h/2, Yb(i,:)' + (h/2)*k1);
    k3 = f(T(i) + h/2, Yb(i,:)' + (h/2)*k2);
    k4 = f(T(i+1), Yb(i,:)' + h*k3);
    Yb(i+1,:) = Yb(i,:) + (h/6)*(k1 + 2*k2 + 2*k3 + k4)';
end


figure('Name','Comparación de dos trayectorias - Atractor de Lorenz','NumberTitle','off');
hold on;
grid on;
xlabel('x'); ylabel('y'); zlabel('z');
title('Comparación de dos trayectorias del sistema de Lorenz (RK4)');
set(gca, 'FontSize', 12);
view(45,30);

% Límites del gráfico
xlim([min([Y(:,1);Yb(:,1)]) max([Y(:,1);Yb(:,1)])]);
ylim([min([Y(:,2);Yb(:,2)]) max([Y(:,2);Yb(:,2)])]);
zlim([min([Y(:,3);Yb(:,3)]) max([Y(:,3);Yb(:,3)])]);

% Trayectorias y puntos móviles
trayectoria1 = plot3(NaN, NaN, NaN, 'r', 'LineWidth', 1.3);
trayectoria2 = plot3(NaN, NaN, NaN, 'b', 'LineWidth', 1.3);
punto1 = plot3(NaN, NaN, NaN, 'ro', 'MarkerFaceColor','r', 'MarkerSize',6);
punto2 = plot3(NaN, NaN, NaN, 'bo', 'MarkerFaceColor','b', 'MarkerSize',6);
legend('Trayectoria 1 (y0=[1,1,1])', 'Trayectoria 2 (y0=[1,1.001,1])', 'Location','best');
% Animación
fps = 60;           
pasos = 10;         
for i = 1:pasos:N
    % Actualiza ambas trayectorias
    set(trayectoria1, 'XData', Y(1:i,1), 'YData', Y(1:i,2), 'ZData', Y(1:i,3));
    set(trayectoria2, 'XData', Yb(1:i,1), 'YData', Yb(1:i,2), 'ZData', Yb(1:i,3));
    % Actualiza puntos móviles
    set(punto1, 'XData', Y(i,1), 'YData', Y(i,2), 'ZData', Y(i,3));
    set(punto2, 'XData', Yb(i,1), 'YData', Yb(i,2), 'ZData', Yb(i,3));
    drawnow;
    pause(1/fps);
end



